﻿// Function to apply an exponent to a value
let applyExponent (exponent: int) (value: float) : float = 
    value ** float exponent
let square = applyExponent 2
let cube = applyExponent 3

// Invoke the square and cube with a value (e.g., 4.0)
let resultSquare = square 4.0
let resultCube = cube 4.0      

// Print the results
printfn "Square of 4: %f" resultSquare  
printfn "Cube of 4: %f" resultCube    



// Tail-recursive function to find the product of all elements in a list
let rec productOfListTailRec (list: int list) (acc: int) : int =
    match list with
    | [] -> acc  
    | head :: tail -> productOfListTailRec tail (acc * head)  

// Sample list
let numbersList = [1; 2; 3; 4; 5]

// Find product of all elements
let resultProduct = productOfListTailRec numbersList 1  

// Print the result
printfn "Product of the list: %d" resultProduct  



// Tail-recursive function to calculate the product of all odd numbers from a given number to 1
let rec productOfOddNumbersTailRec (n: int) (acc: int) : int =
    if n <= 0 then
        acc  
    else
        productOfOddNumbersTailRec (n - 2) (acc * n)  

// Example: Find product of odd numbers from 11
let resultOddProduct = productOfOddNumbersTailRec 11 1  

// Print the result
printfn "Product of odd numbers from 11: %d" resultOddProduct  



// Using the map function to trim spaces from a list of strings
let names = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]
let trimmedNames = List.map (fun (name: string) -> name.Trim()) names

// Print the trimmed names
printfn "Trimmed names: %A" trimmedNames  // ["Charles"; "Babbage"; "Von Neumann"; "Dennis Ritchie"]



// Using Filter and Reduce (fold) on a sequence of the first 700 positive integers
let numbers = Seq.init 700 (fun i -> i + 1) |> Seq.toList
let filteredNumbers = List.filter (fun (n: int) -> n % 5 = 0 && n % 7 = 0) numbers
let sumOfFilteredNumbers = List.fold (+) 0 filteredNumbers

// Print the sum of filtered numbers
printfn "Sum of filtered numbers: %d" sumOfFilteredNumbers 




// Using Filter and Reduce (fold) with a collection of strings
// If you have another definition of `names` elsewhere, rename this variable to avoid conflict
let namesList: string list = ["Nancy"; "akash"; "ishaan"; "Sai"; ""; "illuminati"; "baggi"]

// Filter names that contain the letter 'i' (case-insensitive)
let filteredNames = List.filter (fun (name: string) -> name.ToLower().Contains("i")) namesList

// Concatenate the filtered names using List.reduce
let concatenatedNames = List.reduce (+) filteredNames

// Print the concatenated names
printfn "Concatenated Names: %s" concatenatedNames

